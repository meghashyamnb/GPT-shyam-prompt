---
name: Skill improvement
about: Propose a reusable improvement to Helm QA Verifier
title: "[Skill Improvement] "
labels: enhancement
assignees: ""
---

## Problem observed

Describe what the skill missed, misunderstood, or could do better.

## Why this is reusable

Explain why this applies beyond one specific service/project.

## Proposed rule/check

Describe the new instruction, validation, or test pattern.

## Sanitised example

Provide an example with secrets, internal URLs, confidential names, and production values removed.

## Expected behaviour

What should the skill do next time?

## Risk level

- [ ] Critical
- [ ] High
- [ ] Medium
- [ ] Low

## Validation

How was the proposed improvement tested?

## Suggested files to update

- [ ] `SKILL.md`
- [ ] `references/approved-patterns.md`
- [ ] `references/test-scenarios.md`
- [ ] `CHANGELOG.md`
