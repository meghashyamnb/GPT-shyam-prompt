# Approved Reusable Patterns

This file contains team-approved Helm QA learnings that are reusable across projects.

Do not add confidential service details, production values, credentials, internal URLs, or one-off incident information.

## How to add a pattern

Use this format:

```markdown
## Pattern: <short name>

**When it applies:**  
Describe the situation.

**Risk:**  
Explain the deployment/testing risk.

**QA check:**  
Explain what the skill/tester should verify.

**Negative tests:**  
List the most useful negative scenarios.

**Approved by:**  
PR/reviewer reference.

**Added in:**  
Skill version.
```

---

## Example: Rendered output over source-template appearance

**When it applies:**  
Any Helm template containing values, helpers, conditions, ranges, or environment overrides.

**Risk:**  
A template may look correct while rendering an empty, invalid, or unexpected Kubernetes field.

**QA check:**  
Prefer `helm template` output when judging effective deployment configuration.

**Negative tests:**  
Missing value, empty override, wrong environment file, conditional branch not exercised.

**Added in:**  
v1.0.0
