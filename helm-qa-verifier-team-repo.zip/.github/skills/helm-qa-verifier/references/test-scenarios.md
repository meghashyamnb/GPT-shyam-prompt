# Reusable Helm QA Test Scenarios

Use this file as a team-maintained library of generic test patterns.

## Helm rendering

- Valid values render successfully.
- Required value missing.
- Environment override missing.
- Wrong datatype.
- Empty/null value.
- Conditional true branch.
- Conditional false branch.
- Helper/template reference missing.

## Deployment

- replicas missing/invalid where policy requires it.
- selector and pod labels mismatch.
- image/tag missing.
- resource request missing.
- resource limit missing.
- request/limit invalid.
- readiness probe missing/invalid.
- liveness probe missing/invalid.
- startup probe behaviour where applicable.

## Configuration references

- ConfigMap reference valid.
- ConfigMap reference missing.
- Secret reference valid.
- Secret reference missing.
- Vault enabled path.
- Vault disabled path.

## Policy-as-code

- compliant manifest passes.
- required field missing.
- wrong value.
- wrong case.
- leading/trailing spaces.
- annotation/label at wrong YAML level.
- multiple violations reported.
- policy configuration missing.
- policy validation failure blocks deployment.

## Migration

- old and new replica behaviour equivalent.
- old and new routes/services equivalent.
- environment variables preserved.
- probes preserved or intentionally changed.
- resources preserved or intentionally changed.
- canary flow equivalent.
- rollback behaviour equivalent.
- failed new version does not incorrectly receive traffic.
