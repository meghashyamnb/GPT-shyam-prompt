# Changelog

All notable changes to the Helm QA Verifier should be documented here.

## [1.0.0] - Initial

### Added

- Helm chart discovery
- `helm lint` workflow
- rendered-manifest review
- Kubernetes/OpenShift deployment checks
- Conftest/OPA/Rego policy review
- negative test generation
- DeploymentConfig-to-Helm migration comparison
- canary/readiness/rollback review
- safe read-only defaults
- controlled reusable-learning workflow
