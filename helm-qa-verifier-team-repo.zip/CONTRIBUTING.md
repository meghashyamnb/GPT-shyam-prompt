# Contributing to Helm QA Verifier

This skill should improve through reviewed team contributions, not silent self-modification.

## Contribution flow

```text
Use skill
→ identify reusable gap
→ raise issue or PR
→ peer review
→ update skill/reference
→ update CHANGELOG
→ merge
→ testers update local skill
```

## Good contributions

- recurring Helm failure pattern
- reusable negative test
- new policy-validation scenario
- safer read-only validation command
- migration regression pattern
- canary/readiness/rollback check
- correction for a repeated false positive

## Do not contribute

- secrets
- credentials
- tokens
- production values
- confidential URLs
- personal data
- one-service-only temporary workarounds
- unverified assumptions

## PR checklist

- [ ] Change is reusable across projects.
- [ ] Technical behaviour has been verified.
- [ ] No sensitive information is included.
- [ ] Read-only behaviour remains the default.
- [ ] New destructive commands were not pre-approved.
- [ ] Relevant reference/test scenario was added or updated.
- [ ] CHANGELOG was updated.
- [ ] At least one QA reviewer approved.
- [ ] DevOps/Platform reviewed changes that alter infrastructure assumptions.
