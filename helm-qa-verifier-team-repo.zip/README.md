# Helm QA Verifier

A reusable GitHub Copilot Agent Skill for QA engineers testing Helm, Kubernetes/OpenShift deployment configuration, policy-as-code controls, CI/CD deployment gates, and DeploymentConfig-to-Helm migrations.

The goal is to give testers a repeatable way to review Helm changes, render manifests, identify deployment risks, generate negative tests, and validate policy enforcement without relying only on manual inspection.

> **Important:** This repository should live in the approved office GitHub organisation/repository. Do not copy office source code, internal URLs, credentials, secrets, production values, or proprietary documentation to personal repositories.

---

## What this skill does

The skill helps testers review:

- `Chart.yaml`
- `values.yaml`
- environment-specific values
- Helm templates
- rendered Kubernetes/OpenShift manifests
- Deployments
- Services / Routes / Ingress
- ConfigMaps
- Secret references
- CPU and memory requests/limits
- readiness/liveness/startup probes
- labels and selectors
- annotations
- Vault-related conditional templates
- Conftest / OPA / Rego policies
- Jenkins / CI/CD deployment gates
- canary deployment behaviour
- readiness and traffic switching
- rollback behaviour
- old DeploymentConfig vs new Helm behaviour

It is designed to prefer **read-only validation**.

It must not deploy or modify cluster resources unless the tester explicitly requests and is authorised to do so.

---

# Repository structure

```text
helm-qa-verifier/
├── README.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   └── skill-improvement.md
│   └── skills/
│       └── helm-qa-verifier/
│           ├── SKILL.md
│           └── references/
│               ├── approved-patterns.md
│               └── test-scenarios.md
```

The actual Copilot skill is:

```text
.github/skills/helm-qa-verifier/SKILL.md
```

GitHub Copilot supports repository skills in `.github/skills/`, and personal cross-project skills in `~/.copilot/skills/`.

---

# For repository maintainers

## 1. Create an office GitHub repository

Create a private/internal repository in the approved office GitHub organisation.

Suggested names:

```text
qa-agent-skills
```

or:

```text
helm-qa-verifier
```

Clone it:

```bash
git clone <OFFICE_GITHUB_REPO_URL>
cd <REPO_NAME>
```

Copy this repository structure into it.

Then:

```bash
git add .
git commit -m "Add Helm QA Verifier skill"
git push origin main
```

Recommended: protect `main` and require a pull request for changes to `SKILL.md`.

---

# For testers — recommended installation

## Option 1: Install with GitHub CLI

If your office GitHub CLI supports `gh skill`, first verify:

```bash
gh --version
gh skill --help
```

Preview the skill before installing:

```bash
gh skill preview <OFFICE_ORG>/<OFFICE_REPO> helm-qa-verifier
```

Install it for GitHub Copilot at user scope:

```bash
gh skill install <OFFICE_ORG>/<OFFICE_REPO> helm-qa-verifier \
  --agent github-copilot \
  --scope user
```

Verify:

```bash
gh skill list --agent github-copilot --scope user
```

The skill should then be available across the tester's projects.

To update later:

```bash
gh skill update helm-qa-verifier
```

or:

```bash
gh skill update --all
```

> `gh skill` is a GitHub CLI feature that may require a recent version of GitHub CLI. Follow your organisation's approved software process.

---

## Option 2: Manual installation

If `gh skill` is unavailable, clone the office repository:

```bash
git clone <OFFICE_GITHUB_REPO_URL>
cd <REPO_NAME>
```

Create the Copilot user skills directory:

```bash
mkdir -p ~/.copilot/skills
```

Copy the skill:

```bash
cp -R .github/skills/helm-qa-verifier ~/.copilot/skills/
```

Verify:

```bash
ls -la ~/.copilot/skills/helm-qa-verifier
```

Expected:

```text
SKILL.md
references/
```

Reload VS Code:

```text
Command + Shift + P
```

Run:

```text
Developer: Reload Window
```

The skill is now available across local projects for that user.

---

# First use

Open an office Helm project in VS Code.

Use GitHub Copilot Agent mode.

Start with a read-only discovery prompt:

```text
Use the /helm-qa-verifier skill.

Inspect this repository.

Do not modify files.
Do not deploy anything.
Do not run commands yet.

Identify:
- Helm charts
- values files
- environment-specific values
- templates
- deployment configuration
- Service/Route configuration
- ConfigMaps and Secret templates
- CI/CD configuration
- Conftest/OPA/Rego policy configuration

Then tell me:
1. what you found,
2. what you intend to validate,
3. which read-only commands you want to run.
```

---

# Standard Helm QA review

After discovery:

```text
Use the /helm-qa-verifier skill.

Perform a read-only Helm QA review.

You may run:
- helm lint
- helm template
- conftest test, when already configured and available

Do not:
- deploy
- modify files
- expose Secret values
- run helm install/upgrade/uninstall
- run kubectl apply/delete
- run oc apply/delete

Report:
1. PASS / FAIL / NOT RUN for each validation,
2. critical findings,
3. warnings,
4. migration differences,
5. recommended negative tests,
6. questions for DevOps only when repository evidence is insufficient.
```

---

# DeploymentConfig-to-Helm migration review

```text
Use the /helm-qa-verifier skill.

This repository is migrating from the previous DeploymentConfig/deployment implementation to Helm.

Compare effective old and new behaviour, not just syntax.

Focus on:
- replicas
- image and tag
- labels
- annotations
- environment variables
- CPU/memory requests and limits
- readiness/liveness/startup probes
- ConfigMaps
- Secrets
- Vault behaviour
- Services
- Routes
- deployment strategy
- canary behaviour
- readiness and traffic switching
- rollback
- environment-specific values
- policy validation

Return:
1. expected differences,
2. unexpected differences,
3. high-risk regressions,
4. negative test cases,
5. unanswered questions for DevOps.
```

---

# Expected local tools

The skill can still inspect files without these tools, but stronger validation is possible when they are already installed and approved:

```bash
helm version
conftest --version
oc version
```

Optional schema validation can be used if the organisation already provides an approved validator.

The skill must not automatically install tools.

---

# Safety model

Normal use is read-only.

The skill should never automatically run:

```text
helm install
helm upgrade
helm uninstall

kubectl apply
kubectl delete

oc apply
oc delete
```

The skill should never expose:

- Secret values
- passwords
- tokens
- API keys
- credentials

Testers should inspect terminal commands before approving them.

---

# How the skill improves over time

The skill does **not silently self-train or modify itself**.

Instead, use a controlled team-learning loop:

```text
Tester uses skill
      ↓
New useful pattern / missed scenario discovered
      ↓
Skill reports "Reusable learning candidates"
      ↓
Tester raises GitHub Issue or PR
      ↓
Team reviews the proposed learning
      ↓
Approved learning added to:
references/approved-patterns.md
or SKILL.md
      ↓
CHANGELOG updated
      ↓
New version merged
      ↓
Testers run gh skill update
```

This gives the team continuous improvement without allowing an AI agent to rewrite its own instructions without review.

---

# What should become a reusable learning?

Good candidates:

- a recurring Helm migration defect
- a newly discovered negative test pattern
- a common OpenShift deployment failure
- a useful policy validation check
- a new canary/rollback regression scenario
- a reusable command that is read-only and safe
- a repeated false positive and how to avoid it
- a recurring difference between source templates and rendered manifests

Do **not** add:

- one-service-only values
- production secrets
- credentials
- internal personal data
- temporary incident details
- environment-specific sensitive information

Project-specific rules should stay in that project's repository/documentation unless the rule truly applies organisation-wide.

---

# How testers submit improvements

## Option A — GitHub Issue

Use the provided **Skill improvement** issue template.

A tester should include:

```text
Problem observed:
Why current skill missed it:
Reusable rule/check proposed:
Example with sensitive data removed:
Expected behaviour:
Risk level:
```

## Option B — Pull Request

Update one or more of:

```text
.github/skills/helm-qa-verifier/SKILL.md
.github/skills/helm-qa-verifier/references/approved-patterns.md
.github/skills/helm-qa-verifier/references/test-scenarios.md
CHANGELOG.md
```

PR description should explain:

```text
What changed?
Why is it reusable?
Which failure/test exposed the gap?
How was the new instruction validated?
```

---

# Maintainer review checklist

Before merging a skill improvement:

- [ ] Is the rule reusable across more than one project/service?
- [ ] Is it technically correct?
- [ ] Does it duplicate an existing rule?
- [ ] Could it cause destructive commands?
- [ ] Could it expose secrets?
- [ ] Is the wording precise enough for Copilot?
- [ ] Is there an example or scenario demonstrating why it exists?
- [ ] Has the change been tested on at least one non-production example?
- [ ] Has `CHANGELOG.md` been updated?

---

# Versioning recommendation

Use semantic versions:

```text
v1.0.0
v1.1.0
v1.2.0
v2.0.0
```

Example:

```text
v1.0.0
Initial Helm QA workflow

v1.1.0
Added Vault conditional testing

v1.2.0
Added Conftest policy-failure coverage

v1.3.0
Added canary and rollback regression checks
```

For important releases, create a Git tag:

```bash
git tag v1.1.0
git push origin v1.1.0
```

Teams that need stability can install a pinned/tagged version if supported by their installation method.

---

# Team ownership recommendation

Have at least:

```text
1 primary maintainer
1 backup maintainer
2–3 QA reviewers
```

Suggested ownership:

```text
Maintainers
- approve skill changes
- maintain versions
- review security

Testers
- use the skill
- raise missed scenarios
- contribute examples

DevOps/Platform
- review deployment-policy correctness
- review Helm/OpenShift-specific additions
```

---

# Definition of Done for a skill update

A skill improvement is complete when:

- the instruction has been added
- an example/test scenario exists
- no confidential data is included
- at least one reviewer approves
- the change is documented in `CHANGELOG.md`
- the updated skill works in VS Code Copilot
- testers can update/install it successfully

---

# Quick-start for testers

```bash
# Preview
gh skill preview <OFFICE_ORG>/<OFFICE_REPO> helm-qa-verifier

# Install for all projects
gh skill install <OFFICE_ORG>/<OFFICE_REPO> helm-qa-verifier \
  --agent github-copilot \
  --scope user

# Verify
gh skill list --agent github-copilot --scope user

# Later update
gh skill update helm-qa-verifier
```

Then in VS Code:

```text
Use the /helm-qa-verifier skill to review the current Helm changes.
```

---

# Support

If the skill gives an incorrect result, misses an important case, or repeatedly asks unnecessary questions:

1. capture the generic problem,
2. remove confidential details,
3. raise a Skill Improvement issue,
4. propose the reusable rule,
5. update the skill through PR review.

The objective is for the skill to become the team's **shared Helm QA playbook**, not a one-time prompt.
